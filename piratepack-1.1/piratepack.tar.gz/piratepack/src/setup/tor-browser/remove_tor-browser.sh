#!/bin/bash
HOME=$(echo ~)
rm -rf *
cd
rm .local/share/applications/tor-browser.desktop
rm .local/share/icons/tor-browser.png

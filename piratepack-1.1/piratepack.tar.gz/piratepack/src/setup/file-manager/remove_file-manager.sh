#!/bin/bash
rm -rf *

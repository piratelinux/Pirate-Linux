# Defaults for piratepack initscript
# sourced by /etc/init.d/piratepack
# installed at /etc/default/piratepack by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""

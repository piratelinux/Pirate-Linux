#ifndef URLTESTS_H
#define URLTESTS_H

#include <QTest>
#include <QObject>

class URLTests : public QObject
{
    Q_OBJECT

private slots:
    void urlTests();
};

#endif // URLTESTS_H

void ipcInit();
void ipcShutdown();

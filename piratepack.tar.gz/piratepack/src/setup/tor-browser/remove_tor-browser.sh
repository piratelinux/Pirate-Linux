#!/bin/bash

set -e

maindir="$1"


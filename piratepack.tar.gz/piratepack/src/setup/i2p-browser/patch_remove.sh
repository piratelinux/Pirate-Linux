#!/bin/bash

rm i2p-patch/apps/jrobin/*.jar
rm i2p-patch/installer/lib/wrapper/all/*.jar
rm i2p-patch/installer/lib/wrapper/linux64/i2psvc
rm i2p-patch/installer/lib/wrapper/linux64/libwrapper.so

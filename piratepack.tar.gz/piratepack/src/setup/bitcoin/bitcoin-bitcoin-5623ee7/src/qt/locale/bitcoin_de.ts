<?xml version="1.0" ?><!DOCTYPE TS><TS language="de" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="14"/>
        <source>About Bitcoin</source>
        <translation>Über Bitcoin</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="53"/>
        <source>&lt;b&gt;Bitcoin&lt;/b&gt; version</source>
        <translation>&lt;b&gt;Bitcoin&lt;/b&gt; Version</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="85"/>
        <source>Copyright © 2009-2011 Bitcoin Developers

This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file license.txt or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation>Copyright © 2009-2011 Bitcoin Entwickler

Dies ist experimentelle Software.

Veröffentlicht unter der MIT/X11 Software-Lizenz. Sie können diese in der beiligenden Datei license.txt oder unter http://www.opensource.org/licenses/mit-license.php nachlesen.

Dieses Produkt enthält Software, welche vom OpenSSL Projekt zur Verwendung im OpenSSL Toolkit (http://www.openssl.org/) entwickelt wurde, kryptographische Software von Eric Young (eay@cryptsoft.com) und UPnP Software von Thomas-Bernard.</translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <location filename="../forms/addressbookpage.ui" line="14"/>
        <source>Address Book</source>
        <translation>Adressbuch</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="20"/>
        <source>These are your Bitcoin addresses for receiving payments.  You may want to give a different one to each sender so you can keep track of who is paying you.</source>
        <translation>Dies sind ihre Bitcoin-Adressen zum Empfangen von Zahlungen. Um Ihre Zahlungen zurückverfolgen zu können, schlagen wir vor, jedem Sender eine andere Empfangsaddresse mitzuteilen.</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="33"/>
        <source>Double-click to edit address or label</source>
        <translation>Doppelklick zum Ändern der Adresse oder der Bezeichnung</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="57"/>
        <source>Create a new address</source>
        <translation>Neue Adresse erstellen</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="60"/>
        <source>&amp;New Address...</source>
        <translation>&amp;Neue Adresse...</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="71"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Ausgewählte Adresse in die Zwischenablage kopieren</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="74"/>
        <source>&amp;Copy to Clipboard</source>
        <translation>&amp;In die Zwischenablage kopieren</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="85"/>
        <source>Delete the currently selected address from the list. Only sending addresses can be deleted.</source>
        <translation>Die ausgewählte Adresse aus der Liste entfernen. Sie können nur ausgehende Adressen entfernen.</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="88"/>
        <source>&amp;Delete</source>
        <translation>&amp;Löschen</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="204"/>
        <source>Export Address Book Data</source>
        <translation>Adressbuch exportieren</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="206"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommagetrennte Datei (*.csv)</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="219"/>
        <source>Error exporting</source>
        <translation>Fehler beim Exportieren</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="219"/>
        <source>Could not write to file %1.</source>
        <translation>Konnte Datei %1 nicht zum Schreiben öffnen.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <location filename="../addresstablemodel.cpp" line="77"/>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <location filename="../addresstablemodel.cpp" line="77"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../addresstablemodel.cpp" line="113"/>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="26"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="32"/>
        <source>TextLabel</source>
        <translation>Text Bezeichnung</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="47"/>
        <source>Enter passphrase</source>
        <translation>Passphrase eingeben</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="61"/>
        <source>New passphrase</source>
        <translation>Neue Passphrase</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="75"/>
        <source>Repeat new passphrase</source>
        <translation>Neue Passphrase wiederholen</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="26"/>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Geben Sie die neue Passphrase für die Brieftasche ein.&lt;br/&gt;Bitte benutzen Sie eine Passphrase von &lt;b&gt;zehn oder mehr zufälligen Zeichen&lt;/b&gt; oder &lt;b&gt;acht oder mehr Wörter&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="27"/>
        <source>Encrypt wallet</source>
        <translation>Brieftasche verschlüsseln</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="30"/>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Dieser Vorgang benötigt Ihre Passphrase um die Brieftasche zu entsperren.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="35"/>
        <source>Unlock wallet</source>
        <translation>Brieftasche entsperren</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="38"/>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Dieser Vorgang benötigt Ihre Passphrase um die Brieftasche zu entschlüsseln.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="43"/>
        <source>Decrypt wallet</source>
        <translation>Brieftasche entschlüsseln</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="46"/>
        <source>Change passphrase</source>
        <translation>Passphrase ändern</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="47"/>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Geben Sie die alte und die neue Passphrase der Brieftasche ein.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="91"/>
        <source>Confirm wallet encryption</source>
        <translation>Bestätige die Verschlüsselung der Brieftasche</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="92"/>
        <source>WARNING: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BITCOINS&lt;/b&gt;!
Are you sure you wish to encrypt your wallet?</source>
        <translation>WARNUNG: Wenn Sie Ihre Brieftasche verschlüsseln und Ihre Passphrase verlieren, werden Sie &lt;b&gt;ALLE IHRE BITCOINS VERLIEREN&lt;/b&gt;!
Sind Sie sich sicher, dass Sie Ihre Brieftasche verschlüsseln möchten?</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="101"/>
        <location filename="../askpassphrasedialog.cpp" line="149"/>
        <source>Wallet encrypted</source>
        <translation>Brieftasche verschlüsselt</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="102"/>
        <source>Remember that encrypting your wallet cannot fully protect your bitcoins from being stolen by malware infecting your computer.</source>
        <translation>Beachten Sie, dass das Verschlüsseln Ihrer Brieftasche nicht komplett vor Diebstahl Ihrer Bitcoins durch Malware schützt, die Ihren Computer infiziert hat.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="106"/>
        <location filename="../askpassphrasedialog.cpp" line="113"/>
        <location filename="../askpassphrasedialog.cpp" line="155"/>
        <location filename="../askpassphrasedialog.cpp" line="161"/>
        <source>Wallet encryption failed</source>
        <translation>Verschlüsselung der Brieftasche fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="107"/>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Die Verschlüsselung der Brieftasche ist wegen eines internen Fehlers fehlgeschlagen. Ihre Brieftasche wurde nicht verschlüsselt.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="114"/>
        <location filename="../askpassphrasedialog.cpp" line="162"/>
        <source>The supplied passphrases do not match.</source>
        <translation>Die eingegebenen Passphrasen stimmen nicht überein.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="125"/>
        <source>Wallet unlock failed</source>
        <translation>Entsperrung der Brieftasche fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="126"/>
        <location filename="../askpassphrasedialog.cpp" line="137"/>
        <location filename="../askpassphrasedialog.cpp" line="156"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Die eingegebene Passphrase zum Entschlüsseln der Brieftasche war nicht korrekt.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="136"/>
        <source>Wallet decryption failed</source>
        <translation>Entschlüsselung der Brieftasche fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="150"/>
        <source>Wallet passphrase was succesfully changed.</source>
        <translation>Die Passphrase der Brieftasche wurde erfolgreich geändert.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <location filename="../bitcoingui.cpp" line="63"/>
        <source>Bitcoin Wallet</source>
        <translation>Bitcoin-Brieftasche</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="132"/>
        <source>Synchronizing with network...</source>
        <translation>Synchronisiere mit Netzwerk...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="135"/>
        <source>Block chain synchronization in progress</source>
        <translation>Synchronisiere mit der Blockkette</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="164"/>
        <source>&amp;Overview</source>
        <translation>&amp;Übersicht</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="165"/>
        <source>Show general overview of wallet</source>
        <translation>Zeige allgemeine Übersicht der Brieftasche</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="170"/>
        <source>&amp;Transactions</source>
        <translation>&amp;Transaktionen</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="171"/>
        <source>Browse transaction history</source>
        <translation>Transaktionsverlauf durchsehen</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="176"/>
        <source>&amp;Address Book</source>
        <translation>&amp;Adressbuch</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="177"/>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Gespeicherte Adressen und Bezeichnungen bearbeiten</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="182"/>
        <source>&amp;Receive coins</source>
        <translation>&amp;Bitcoins empfangen</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="183"/>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Liste der Adressen zum Empfangen von Zahlungen anzeigen</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="188"/>
        <source>&amp;Send coins</source>
        <translation>&amp;Bitcoins überweisen</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="189"/>
        <source>Send coins to a bitcoin address</source>
        <translation>Bitcoins an eine Bitcoin-Adresse überweisen</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="200"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="201"/>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="204"/>
        <source>&amp;About %1</source>
        <translation>&amp;Über %1</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="205"/>
        <source>Show information about Bitcoin</source>
        <translation>Informationen über Bitcoin anzeigen</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="207"/>
        <source>&amp;Options...</source>
        <translation>&amp;Einstellungen...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="208"/>
        <source>Modify configuration options for bitcoin</source>
        <translation>Einstellungen für Bitcoin ändern</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="210"/>
        <source>Open &amp;Bitcoin</source>
        <translation>&amp;Bitcoin öffnen</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="211"/>
        <source>Show the Bitcoin window</source>
        <translation>Bitcoin-Fenster anzeigen</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="212"/>
        <source>&amp;Export...</source>
        <translation>&amp;Exportieren...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="213"/>
        <source>Export the current view to a file</source>
        <translation>Aktuelle Ansicht in eine Datei exportieren</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="214"/>
        <source>&amp;Encrypt Wallet</source>
        <translation>Brieftasche &amp;verschlüsseln</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="215"/>
        <source>Encrypt or decrypt wallet</source>
        <translation>Brieftasche ent- oder verschlüsseln</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="217"/>
        <source>&amp;Change Passphrase</source>
        <translation>Passphrase &amp;ändern</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="218"/>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Ändert die Passphrase, die für die Verschlüsselung der Brieftasche benutzt wird</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="239"/>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="242"/>
        <source>&amp;Settings</source>
        <translation>&amp;Einstellungen</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="248"/>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="254"/>
        <source>Tabs toolbar</source>
        <translation>Registerkarten-Leiste</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="262"/>
        <source>Actions toolbar</source>
        <translation>Aktionen-Werkzeugleiste</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="273"/>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="355"/>
        <source>bitcoin-qt</source>
        <translation>bitcoin-qt</translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="396"/>
        <source>%n active connection(s) to Bitcoin network</source>
        <translation><numerusform>%n aktive Verbindung zum Bitcoin-Netzwerk</numerusform><numerusform>%n aktive Verbindungen zum Bitcoin-Netzwerk</numerusform></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="411"/>
        <source>Downloaded %1 of %2 blocks of transaction history.</source>
        <translation>%1 von %2 Blöcken des Transaktionsverlauf heruntergeladen.</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="417"/>
        <source>Downloaded %1 blocks of transaction history.</source>
        <translation>%1 Blöcke des Transaktionsverlaufs heruntergeladen.</translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="428"/>
        <source>%n second(s) ago</source>
        <translation><numerusform>vor %n Sekunde</numerusform><numerusform>vor %n Sekunden</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="432"/>
        <source>%n minute(s) ago</source>
        <translation><numerusform>vor %n Minute</numerusform><numerusform>vor %n Minuten</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="436"/>
        <source>%n hour(s) ago</source>
        <translation><numerusform>vor %n Stunde</numerusform><numerusform>vor %n Stunden</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="440"/>
        <source>%n day(s) ago</source>
        <translation><numerusform>vor %n Tag</numerusform><numerusform>vor %n Tagen</numerusform></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="446"/>
        <source>Up to date</source>
        <translation>Auf aktuellem Stand</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="451"/>
        <source>Catching up...</source>
        <translation>Hole auf...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="457"/>
        <source>Last received block was generated %1.</source>
        <translation>Der letzte empfangene Block wurde am %1 generiert.</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="508"/>
        <source>This transaction is over the size limit.  You can still send it for a fee of %1, which goes to the nodes that process your transaction and helps to support the network.  Do you want to pay the fee?</source>
        <translation>Die Transaktion übersteigt das Größenlimit. Sie können sie jedoch senden, wenn Sie einen zusätzlichen Betrag von %1 zahlen. Dieser geht an die Knoten, die Ihre Transaktion bearbeiten und unterstützt das Bitcoin-Netzwerk. Möchten Sie die Gebühr bezahlen?</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="513"/>
        <source>Sending...</source>
        <translation>Senden...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="538"/>
        <source>Sent transaction</source>
        <translation>Gesendete Transaktion</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="539"/>
        <source>Incoming transaction</source>
        <translation>Empfangene Transaktion</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="540"/>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Datum: %1
Betrag: %2
Typ: %3
Adresse: %4</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="639"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Brieftasche ist &lt;b&gt;verschlüsselt&lt;/b&gt; und momentan &lt;b&gt;entsperrt&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="647"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Brieftasche ist &lt;b&gt;verschlüsselt&lt;/b&gt; und momentan &lt;b&gt;gesperrt&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>DisplayOptionsPage</name>
    <message>
        <location filename="../optionsdialog.cpp" line="270"/>
        <source>&amp;Unit to show amounts in: </source>
        <translation>&amp;Einheit der Beträge:</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="274"/>
        <source>Choose the default subdivision unit to show in the interface, and when sending coins</source>
        <translation>Wählen Sie die Standard-Unterteilungseinheit, die in der Benutzeroberfläche und beim Senden von Bitcoins angezeigt werden soll</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="281"/>
        <source>Display addresses in transaction list</source>
        <translation>Adressen in der Transaktionsliste anzeigen</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="14"/>
        <source>Edit Address</source>
        <translation>Adresse bearbeiten</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="25"/>
        <source>&amp;Label</source>
        <translation>&amp;Bezeichnung</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="35"/>
        <source>The label associated with this address book entry</source>
        <translation>Die Bezeichnung dieses Adressbuchseintrags</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="42"/>
        <source>&amp;Address</source>
        <translation>&amp;Adresse</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="52"/>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>Die Adresse des Adressbucheintrags. Diese kann nur für Zahlungsadressen bearbeitet werden.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="20"/>
        <source>New receiving address</source>
        <translation>Neue Empfangsadresse</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="24"/>
        <source>New sending address</source>
        <translation>Neue Zahlungsadresse</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="27"/>
        <source>Edit receiving address</source>
        <translation>Empfangsadresse bearbeiten</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="31"/>
        <source>Edit sending address</source>
        <translation>Zahlungsadresse bearbeiten</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="87"/>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>Die eingegebene Adresse &quot;%1&quot; befindet sich bereits im Adressbuch.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="92"/>
        <source>The entered address &quot;%1&quot; is not a valid bitcoin address.</source>
        <translation>Die eingegebene Adresse &quot;%1&quot; ist keine gültige Bitcoin-Adresse.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="97"/>
        <source>Could not unlock wallet.</source>
        <translation>Die Brieftasche konnte nicht entsperrt werden.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="102"/>
        <source>New key generation failed.</source>
        <translation>Neue Schlüsselgenerierung fehlgeschlagen.</translation>
    </message>
</context>
<context>
    <name>MainOptionsPage</name>
    <message>
        <location filename="../optionsdialog.cpp" line="170"/>
        <source>&amp;Start Bitcoin on window system startup</source>
        <translation>&amp;Bitcoin beim Systemstart ausführen</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="171"/>
        <source>Automatically start Bitcoin after the computer is turned on</source>
        <translation>Bitcoin automatisch starten, wenn der Computer eingeschaltet wird</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="175"/>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;In den Infobereich statt in die Taskleiste minimieren</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="176"/>
        <source>Show only a tray icon after minimizing the window</source>
        <translation>Nur ein Symbol im Infobereich anzeigen, wenn das Fenster minimiert wird</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="180"/>
        <source>Map port using &amp;UPnP</source>
        <translation>Portweiterleitung via &amp;UPnP</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="181"/>
        <source>Automatically open the Bitcoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Automatisch den Bitcoin Client-Port auf dem Router öffnen. Dies funktioniert nur, wenn Ihr Router UPnP unterstützt und dies aktiviert ist.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="185"/>
        <source>M&amp;inimize on close</source>
        <translation>Beim Schließen m&amp;inimieren</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="186"/>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Minimiert die Anwendung anstatt sie zu Beenden, wenn das Fenster geschlossen wird. Wenn dies aktiviert ist, müssen Sie das Programm über &quot;Beenden&quot; im Menü schließen.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="190"/>
        <source>&amp;Connect through SOCKS4 proxy:</source>
        <translation>&amp;Über einen SOCKS4-Proxy verbinden:</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="191"/>
        <source>Connect to the Bitcon network through a SOCKS4 proxy (e.g. when connecting through Tor)</source>
        <translation>Über einen SOCKS4-Proxy zum Bitcoin-Netzwerk verbinden (bspw. für eine Verbindung über Tor)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="196"/>
        <source>Proxy &amp;IP: </source>
        <translation>Proxy-&amp;IP:</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="202"/>
        <source>IP address of the proxy (e.g. 127.0.0.1)</source>
        <translation>IP-Adresse des Proxy-Servers (z.B. 127.0.0.1)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="205"/>
        <source>&amp;Port: </source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="211"/>
        <source>Port of the proxy (e.g. 1234)</source>
        <translation>Port des Proxy-Servers (z.B. 1234)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="217"/>
        <source>Optional transaction fee per KB that helps make sure your transactions are processed quickly.  Most transactions are 1KB.  Fee 0.01 recommended.</source>
        <translation>Zusätzliche Transaktionsgebühr pro KB, welche sicherstellt, dass Ihre Transaktionen schnell bearbeitet werden. Die meisten Transaktionen sind 1 KB groß. Eine Gebühr von 0.01 wird empfohlen.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="223"/>
        <source>Pay transaction &amp;fee</source>
        <translation>Transaktions&amp;gebühr bezahlen</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="226"/>
        <source>Optional transaction fee per KB that helps make sure your transactions are processed quickly. Most transactions are 1KB. Fee 0.01 recommended.</source>
        <translation>Zusätzliche Transaktionsgebühr pro KB, welche sicherstellt, dass Ihre Transaktionen schnell bearbeitet werden. Die meisten Transaktionen sind 1 KB groß. Eine Gebühr von 0.01 wird empfohlen.</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../optionsdialog.cpp" line="79"/>
        <source>Main</source>
        <translation>Haupt</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="84"/>
        <source>Display</source>
        <translation>Anzeige</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="104"/>
        <source>Options</source>
        <translation>Einstellungen</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <location filename="../forms/overviewpage.ui" line="14"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="40"/>
        <source>Balance:</source>
        <translation>Kontostand:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="47"/>
        <source>123.456 BTC</source>
        <translation>123.456 BTC</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="54"/>
        <source>Number of transactions:</source>
        <translation>Anzahl der Transaktionen:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="61"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="68"/>
        <source>Unconfirmed:</source>
        <translation>Unbestätigt:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="75"/>
        <source>0 BTC</source>
        <translation>0 BTC</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="82"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Wallet&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Brieftasche&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="122"/>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Letzte Transaktionen&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="103"/>
        <source>Your current balance</source>
        <translation>Ihr aktueller Kontostand</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="108"/>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Anzahl der Transaktionen, die noch bestätigt werden müssen und noch nicht zum aktuellen Kontostand zählen</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="111"/>
        <source>Total number of transactions in wallet</source>
        <translation>Anzahl aller Transaktionen in der Brieftasche</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="14"/>
        <location filename="../sendcoinsdialog.cpp" line="109"/>
        <location filename="../sendcoinsdialog.cpp" line="114"/>
        <location filename="../sendcoinsdialog.cpp" line="119"/>
        <location filename="../sendcoinsdialog.cpp" line="124"/>
        <location filename="../sendcoinsdialog.cpp" line="130"/>
        <location filename="../sendcoinsdialog.cpp" line="135"/>
        <location filename="../sendcoinsdialog.cpp" line="140"/>
        <source>Send Coins</source>
        <translation>Bitcoins überweisen</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="64"/>
        <source>Send to multiple recipients at once</source>
        <translation>An mehrere Empfänger auf einmal überweisen</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="67"/>
        <source>&amp;Add recipient...</source>
        <translation>&amp;Empfänger hinzufügen...</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="84"/>
        <source>Clear all</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="103"/>
        <source>Balance:</source>
        <translation>Kontostand:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="110"/>
        <source>123.456 BTC</source>
        <translation>123.456 BTC</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="141"/>
        <source>Confirm the send action</source>
        <translation>Überweisung bestätigen</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="144"/>
        <source>&amp;Send</source>
        <translation>&amp;Überweisen</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="85"/>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; an %2 (%3)</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="88"/>
        <source>Confirm send coins</source>
        <translation>Überweisung bestätigen</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="89"/>
        <source>Are you sure you want to send %1?</source>
        <translation>Sind Sie sich sicher, dass Sie folgendes überweisen möchten: %1?</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="89"/>
        <source> and </source>
        <translation> und </translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="110"/>
        <source>The recepient address is not valid, please recheck.</source>
        <translation>Die Empfangsadresse ist ungültig, bitte nochmals überprüfen.</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="115"/>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Der zu zahlende Betrag muss mehr als 0 betragen.</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="120"/>
        <source>Amount exceeds your balance</source>
        <translation>Der Betrag übersteigt Ihren Kontostand</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="125"/>
        <source>Total exceeds your balance when the %1 transaction fee is included</source>
        <translation>Summe übersteigt aufgrund der Transaktionsgebühr in Höhe von %1 Ihren Kontostand</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="131"/>
        <source>Duplicate address found, can only send to each address once in one send operation</source>
        <translation>Doppelte Adresse gefunden. Pro Vorgang kann an eine Adresse nur einmalig etwas überwiesen werden</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="136"/>
        <source>Error: Transaction creation failed  </source>
        <translation>Fehler: Transaktionserstellung fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="141"/>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Fehler: Die Transaktion wurde abgelehnt. Dies kann passieren, wenn einige Ihrer Bitcoins aus Ihrer Brieftasche bereits ausgegeben wurden (z.B. aus einer Sicherungskopie Ihrer wallet.dat).</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="14"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="29"/>
        <source>A&amp;mount:</source>
        <translation>&amp;Betrag:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="42"/>
        <source>Pay &amp;To:</source>
        <translation>&amp;Empfänger:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="66"/>
        <location filename="../sendcoinsentry.cpp" line="26"/>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Geben Sie hier eine Bezeichnung der Adresse ein, um sie zum Adressbuch hinzuzufügen</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="75"/>
        <source>&amp;Label:</source>
        <translation>&amp;Bezeichnung:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="93"/>
        <source>The address to send the payment to  (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Die Empfangsadresse für die Überweisung (z.B. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="103"/>
        <source>Choose adress from address book</source>
        <translation>Adresse aus dem Adressbuch auswählen</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="113"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="120"/>
        <source>Paste address from clipboard</source>
        <translation>Adresse aus der Zwischenablage einfügen</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="130"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="137"/>
        <source>Remove this recipient</source>
        <translation>Diesen Empfänger entfernen</translation>
    </message>
    <message>
        <location filename="../sendcoinsentry.cpp" line="25"/>
        <source>Enter a Bitcoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Bitcoin-Adresse eingeben (z.B. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <location filename="../transactiondesc.cpp" line="34"/>
        <source>Open for %1 blocks</source>
        <translation>Offen für %1 Blöcke</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="36"/>
        <source>Open until %1</source>
        <translation>Offen bis %1</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="42"/>
        <source>%1/offline?</source>
        <translation>%1/offline?</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="44"/>
        <source>%1/unconfirmed</source>
        <translation>%1/unbestätigt</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="46"/>
        <source>%1 confirmations</source>
        <translation>%1 Bestätigungen</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="63"/>
        <source>&lt;b&gt;Status:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Status:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="68"/>
        <source>, has not been successfully broadcast yet</source>
        <translation>; wurde noch nicht erfolgreich gesendet</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="70"/>
        <source>, broadcast through %1 node</source>
        <translation>; über %1 Knoten gesendet</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="72"/>
        <source>, broadcast through %1 nodes</source>
        <translation>; über %1 Knoten gesendet</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="76"/>
        <source>&lt;b&gt;Date:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Datum:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="83"/>
        <source>&lt;b&gt;Source:&lt;/b&gt; Generated&lt;br&gt;</source>
        <translation>&lt;b&gt;Quelle:&lt;/b&gt; Generiert&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="89"/>
        <location filename="../transactiondesc.cpp" line="106"/>
        <source>&lt;b&gt;From:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Von:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="106"/>
        <source>unknown</source>
        <translation>unbekannt</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="107"/>
        <location filename="../transactiondesc.cpp" line="130"/>
        <location filename="../transactiondesc.cpp" line="189"/>
        <source>&lt;b&gt;To:&lt;/b&gt; </source>
        <translation>&lt;b&gt;An:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="110"/>
        <source> (yours, label: </source>
        <translation> (Ihre, Bezeichnung: </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="112"/>
        <source> (yours)</source>
        <translation> (Ihre)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="147"/>
        <location filename="../transactiondesc.cpp" line="161"/>
        <location filename="../transactiondesc.cpp" line="206"/>
        <location filename="../transactiondesc.cpp" line="223"/>
        <source>&lt;b&gt;Credit:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Gutschrift:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="149"/>
        <source>(%1 matures in %2 more blocks)</source>
        <translation>(%1 reift in weiteren %2 Blöcken)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="153"/>
        <source>(not accepted)</source>
        <translation>(nicht angenommen)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="197"/>
        <location filename="../transactiondesc.cpp" line="205"/>
        <location filename="../transactiondesc.cpp" line="220"/>
        <source>&lt;b&gt;Debit:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Belastung:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="211"/>
        <source>&lt;b&gt;Transaction fee:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Transaktionsgebühr:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="227"/>
        <source>&lt;b&gt;Net amount:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Nettobetrag:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="233"/>
        <source>Message:</source>
        <translation>Nachricht:</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="235"/>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="238"/>
        <source>Generated coins must wait 120 blocks before they can be spent.  When you generated this block, it was broadcast to the network to be added to the block chain.  If it fails to get into the chain, it will change to &quot;not accepted&quot; and not be spendable.  This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Generierte Bitcoins müssen 120 Blöcke lang warten, bevor sie ausgegeben werden können. Als Sie diesen Block generierten, wurde er an das Netzwerk gesendet, um ihn der Blockkette hinzuzufügen. Falls dies fehlschlägt wird der Status in &quot;nicht angenommen&quot; geändert und der Betrag wird nicht verfügbar werden. Das kann gelegentlich passieren, wenn ein anderer Knoten einen Block zur selben Zeit wie Sie generierte.</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="14"/>
        <source>Transaction details</source>
        <translation>Transaktionsdetails</translation>
    </message>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="20"/>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Dieser Bereich zeigt eine detaillierte Beschreibung der Transaktion an</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message numerus="yes">
        <location filename="../transactiontablemodel.cpp" line="274"/>
        <source>Open for %n block(s)</source>
        <translation><numerusform>Offen für %n Block</numerusform><numerusform>Offen für %n Blöcke</numerusform></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="277"/>
        <source>Open until %1</source>
        <translation>Offen bis %1</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="280"/>
        <source>Offline (%1 confirmations)</source>
        <translation>Nicht verbunden (%1 Bestätigungen)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="283"/>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Unbestätigt (%1 von %2 Bestätigungen)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="286"/>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Bestätigt (%1 Bestätigungen)</translation>
    </message>
    <message numerus="yes">
        <location filename="../transactiontablemodel.cpp" line="295"/>
        <source>Mined balance will be available in %n more blocks</source>
        <translation><numerusform>Der erarbeitete Betrag wird in %n Block verfügbar sein</numerusform><numerusform>Der erarbeitete Betrag wird in %n Blöcken verfügbar sein</numerusform></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="301"/>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Dieser Block wurde von keinem anderen Knoten empfangen und wird wahrscheinlich nicht angenommen werden!</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="304"/>
        <source>Generated but not accepted</source>
        <translation>Generiert, jedoch nicht angenommen</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="347"/>
        <source>Received with</source>
        <translation>Empfangen durch</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="349"/>
        <source>Received from IP</source>
        <translation>Empfangen von IP</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="351"/>
        <source>Sent to</source>
        <translation>Überwiesen an</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="353"/>
        <source>Sent to IP</source>
        <translation>Überwiesen an IP</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="355"/>
        <source>Payment to yourself</source>
        <translation>Zahlung an Sie selbst</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="357"/>
        <source>Mined</source>
        <translation>Erarbeitet</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="395"/>
        <source>(n/a)</source>
        <translation>(k.A.)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="594"/>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Transaktionsstatus. Fahren Sie mit der Maus über dieses Feld, um die Anzahl der Bestätigungen zu sehen.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="596"/>
        <source>Date and time that the transaction was received.</source>
        <translation>Datum und Uhrzeit als die Transaktion empfangen wurde.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="598"/>
        <source>Type of transaction.</source>
        <translation>Art der Transaktion.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="600"/>
        <source>Destination address of transaction.</source>
        <translation>Empfangsadresse der Transaktion.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="602"/>
        <source>Amount removed from or added to balance.</source>
        <translation>Betrag vom Kontostand entfernt oder hinzugefügt.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <location filename="../transactionview.cpp" line="55"/>
        <location filename="../transactionview.cpp" line="71"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="56"/>
        <source>Today</source>
        <translation>Heute</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="57"/>
        <source>This week</source>
        <translation>Diese Woche</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="58"/>
        <source>This month</source>
        <translation>Diesen Monat</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="59"/>
        <source>Last month</source>
        <translation>Letzten Monat</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="60"/>
        <source>This year</source>
        <translation>Dieses Jahr</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="61"/>
        <source>Range...</source>
        <translation>Bereich...</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="72"/>
        <source>Received with</source>
        <translation>Empfangen durch</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="74"/>
        <source>Sent to</source>
        <translation>Überwiesen an</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="76"/>
        <source>To yourself</source>
        <translation>Zu Ihnen selbst</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="77"/>
        <source>Mined</source>
        <translation>Erarbeitet</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="78"/>
        <source>Other</source>
        <translation>Andere</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="84"/>
        <source>Enter address or label to search</source>
        <translation>Zu suchende Adresse oder Bezeichnung eingeben</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="90"/>
        <source>Min amount</source>
        <translation>Kleinster Betrag</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="125"/>
        <source>Copy address</source>
        <translation>Adresse kopieren</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="126"/>
        <source>Copy label</source>
        <translation>Bezeichnung kopieren</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="127"/>
        <source>Edit label</source>
        <translation>Bezeichnung bearbeiten</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="128"/>
        <source>Show details...</source>
        <translation>Details anzeigen...</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="261"/>
        <source>Export Transaction Data</source>
        <translation>Transaktionen exportieren</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="263"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommagetrennte Datei (*.csv)</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="271"/>
        <source>Confirmed</source>
        <translation>Bestätigt</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="272"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="273"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="274"/>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="275"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="276"/>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="277"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="281"/>
        <source>Error exporting</source>
        <translation>Fehler beim Exportieren</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="281"/>
        <source>Could not write to file %1.</source>
        <translation>Konnte nicht in Datei %1 schreiben.</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="369"/>
        <source>Range:</source>
        <translation>Bereich:</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="377"/>
        <source>to</source>
        <translation>bis</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <location filename="../walletmodel.cpp" line="144"/>
        <source>Sending...</source>
        <translation>Überweise...</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <location filename="../bitcoinstrings.cpp" line="3"/>
        <source>Bitcoin version</source>
        <translation>Bitcoin Version</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="4"/>
        <source>Usage:</source>
        <translation>Verwendung:</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="5"/>
        <source>Send command to -server or bitcoind
</source>
        <translation>Sende Befehl an -server oder bitcoind
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="6"/>
        <source>List commands
</source>
        <translation>Befehle auflisten
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="7"/>
        <source>Get help for a command
</source>
        <translation>Hilfe für Befehl erhalten
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="8"/>
        <source>Options:
</source>
        <translation>Einstellungen:</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="9"/>
        <source>Specify configuration file (default: bitcoin.conf)
</source>
        <translation>Bitte wählen Sie eine Konfigurationsdatei (Standard: bitcoin.conf)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="10"/>
        <source>Specify pid file (default: bitcoind.pid)
</source>
        <translation>Bitte wählen Sie den Namen der PID Datei (Standard bitcoind.pid)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="11"/>
        <source>Generate coins
</source>
        <translation>Erarbeite Bitcoins</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="12"/>
        <source>Don't generate coins
</source>
        <translation>Keine Bitcoins erarbeiten
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="13"/>
        <source>Start minimized
</source>
        <translation>minimiert starten</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="14"/>
        <source>Specify data directory
</source>
        <translation>Bitte wählen Sie das Datenverzeichnis</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="15"/>
        <source>Specify connection timeout (in milliseconds)
</source>
        <translation>Netzwerkverbindungsabbruch nach (in Millisekunden)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="16"/>
        <source>Connect through socks4 proxy
</source>
        <translation>Durch SOCKS4-Proxy verbinden</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="17"/>
        <source>Allow DNS lookups for addnode and connect
</source>
        <translation>Erlaube DNS Namensauflösung für addnode und connect</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="18"/>
        <source>Add a node to connect to
</source>
        <translation>Bitcoin Knoten hinzufügen
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="19"/>
        <source>Connect only to the specified node
</source>
        <translation>Nur zu angegebenen Knoten verbinden
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="20"/>
        <source>Don't accept connections from outside
</source>
        <translation>Keine externen Transatkionen akzeptieren</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="21"/>
        <source>Don't attempt to use UPnP to map the listening port
</source>
        <translation>UPnP nicht verwenden</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="22"/>
        <source>Attempt to use UPnP to map the listening port
</source>
        <translation>Versuche eine Verbindung mittels UPnP herzustellen</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="23"/>
        <source>Fee per KB to add to transactions you send
</source>
        <translation>Gebühr pro KB, die gesendeten Transaktionen hinzugefügt wird
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="24"/>
        <source>Accept command line and JSON-RPC commands
</source>
        <translation>Erlaube Kommandozeilen und JSON-RPC Befehle
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="25"/>
        <source>Run in the background as a daemon and accept commands
</source>
        <translation>Als Hintergrunddienst starten und Befehle akzeptieren
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="26"/>
        <source>Use the test network
</source>
        <translation>Das Test Netzwerk verwenden
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="27"/>
        <source>Username for JSON-RPC connections
</source>
        <translation>Benutzername für JSON-RPC Verbindungen
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="28"/>
        <source>Password for JSON-RPC connections
</source>
        <translation>Passwort für JSON-RPC Verbindungen
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="29"/>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 8332)
</source>
        <translation>Port für JSON-RPC Befehle (Standard: 8332)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="30"/>
        <source>Allow JSON-RPC connections from specified IP address
</source>
        <translation>JSON-RPC Befehle nur von dieser IP-Adresse erlauben
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="31"/>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)
</source>
        <translation>Befehle an Bitcoin Knoten &lt;ip&gt; senden (Standard: 127.0.0.1)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="32"/>
        <source>Set key pool size to &lt;n&gt; (default: 100)
</source>
        <translation>Menge der vorgenerierten Adressen (Standard: 100)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="33"/>
        <source>Rescan the block chain for missing wallet transactions
</source>
        <translation>Blockkette nach verlorenen Transaktionen durchsuchen (rescan)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="34"/>
        <source>
SSL options: (see the Bitcoin Wiki for SSL setup instructions)
</source>
        <translation>SSL Einstellungen: (Siehe im BitCoin-Wiki für eine detallierte Beschreibung)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="37"/>
        <source>Use OpenSSL (https) for JSON-RPC connections
</source>
        <translation>JSON-RPC Befehle über OpenSSL (https)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="38"/>
        <source>Server certificate file (default: server.cert)
</source>
        <translation>SSL Server Zertifikat (Standard: server.cert)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="39"/>
        <source>Server private key (default: server.pem)
</source>
        <translation>Privater SSL Schlüssel (Standard: server.pem)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="40"/>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)
</source>
        <translation>Erlaubte Kryptographiealgorithmen (Standard: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="43"/>
        <source>This help message
</source>
        <translation>Dieser Hilfetext</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="44"/>
        <source>Cannot obtain a lock on data directory %s.  Bitcoin is probably already running.</source>
        <translation>Konnte das Datenverzeichnis %s nicht sperren. Evtl. wurde das Programm mehrfach gestartet.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="47"/>
        <source>Loading addresses...</source>
        <translation>Lade Adressen...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="48"/>
        <source>Error loading addr.dat      
</source>
        <translation>Fehler beim Laden der addr.dat
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="49"/>
        <source>Loading block index...</source>
        <translation>Lade Blockindex...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="50"/>
        <source>Error loading blkindex.dat      
</source>
        <translation>Fehler beim laden der blkindex.dat</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="51"/>
        <source>Loading wallet...</source>
        <translation>Lade Geldbörse...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="52"/>
        <source>Error loading wallet.dat: Wallet corrupted      
</source>
        <translation>Fehler beim Laden von wallet.dat: Brieftasche beschädigt
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="53"/>
        <source>Error loading wallet.dat: Wallet requires newer version of Bitcoin      
</source>
        <translation>Fehler beim Laden von wallet.dat: Neuere Version von Bitcoin notwendig 
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="55"/>
        <source>Error loading wallet.dat      
</source>
        <translation>Fehler beim Laden von wallet.dat</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="56"/>
        <source>Rescanning...</source>
        <translation>Lade neu...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="57"/>
        <source>Done loading</source>
        <translation>Laden abgeschlossen</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="58"/>
        <source>Invalid -proxy address</source>
        <translation>Fehlerhafte Proxy Adresse</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="59"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;</source>
        <translation>Ungültige Angabe für -paytxfee=&lt;Betrag&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="60"/>
        <source>Warning: -paytxfee is set very high.  This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Warnung: -paytxfee ist auf einen sehr hohen Wert gesetzt. Dies ist die Gebühr die beim senden einer Transaktion fällig wird.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="63"/>
        <source>Error: CreateThread(StartNode) failed</source>
        <translation>Fehler: CreateThread(StartNode) fehlerhaft</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="64"/>
        <source>Warning: Disk space is low  </source>
        <translation>Warnung: Festplattenplatz wird knapp.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="65"/>
        <source>Unable to bind to port %d on this computer.  Bitcoin is probably already running.</source>
        <translation>Fehler beim registrieren des Ports %d auf diesem Computer. Evtl. läuft BitCoin bereits</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="68"/>
        <source>This transaction is over the size limit.  You can still send it for a fee of %s, which goes to the nodes that process your transaction and helps to support the network.  Do you want to pay the fee?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="72"/>
        <source>Enter the current passphrase to the wallet.</source>
        <translation>Geben Sie bitte das Passwort für die Brieftasche ein.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="73"/>
        <source>Passphrase</source>
        <translation>Passwort</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="74"/>
        <source>Please supply the current wallet decryption passphrase.</source>
        <translation>Bitte die aktuelle Passphrase zur Entschlüsselung eingeben.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="75"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Das eingegebene Passwort  für die Brieftasche war fehlerhaft</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="76"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="77"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="78"/>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="79"/>
        <source>Debit</source>
        <translation>Debitoren</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="80"/>
        <source>Credit</source>
        <translation>Kreditoren</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="81"/>
        <source>Open for %d blocks</source>
        <translation>Öffne für %d Blöcke</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="82"/>
        <source>Open until %s</source>
        <translation>Geöffnet bis %s</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="83"/>
        <source>%d/offline?</source>
        <translation>%d/offline?</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="84"/>
        <source>%d/unconfirmed</source>
        <translation>%d/unbestätigt</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="85"/>
        <source>%d confirmations</source>
        <translation>%d Bestätigungen</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="86"/>
        <source>Generated</source>
        <translation>Generiert</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="87"/>
        <source>Generated (%s matures in %d more blocks)</source>
        <translation>Erstellt (%s reift nach %d weiteren Blöcken)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="88"/>
        <source>Generated - Warning: This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Generiert - Warnung: Dieser Block wurde bei keinem anderen Knoten empfangen und wird wahrscheinlich nicht akzeptiert!</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="91"/>
        <source>Generated (not accepted)</source>
        <translation>Generiert (nicht akzeptiert)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="92"/>
        <source>From: </source>
        <translation>Von:</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="93"/>
        <source>Received with: </source>
        <translation>Erhalten mit:</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="94"/>
        <source>Payment to yourself</source>
        <translation>Bezahlung an sich selbst</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="95"/>
        <source>To: </source>
        <translation>An:</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="96"/>
        <source>    Generating</source>
        <translation>Erzeuge</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="97"/>
        <source>(not connected)</source>
        <translation>(nicht verbunden)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="98"/>
        <source>     %d connections     %d blocks     %d transactions</source>
        <translation>%d Verbindungen %d Blöcke %d Transaktionen</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="99"/>
        <source>Wallet already encrypted.</source>
        <translation>Brieftasche ist bereits verschlüsselt.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="100"/>
        <source>Enter the new passphrase to the wallet.
Please use a passphrase of 10 or more random characters, or eight or more words.</source>
        <translation>Geben Sie die neue Passphrase für die Brieftasche ein
Bitte benutzen Sie eine Passphrase von 10 oder mehr zufälligen Zeichen oder acht oder mehr Wörtern.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="104"/>
        <source>Error: The supplied passphrase was too short.</source>
        <translation>Fehler: Das eingegebene Passwort war zu kurz.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="105"/>
        <source>WARNING: If you encrypt your wallet and lose your passphrase, you will LOSE ALL OF YOUR BITCOINS!
Are you sure you wish to encrypt your wallet?</source>
        <translation>WARNUNG: Wenn Sie Ihre Brieftasche verschlüsseln und Ihre Passphrase verlieren, werden Sie &lt;b&gt;ALLE IHRE BITCOINS VERLIEREN&lt;/b&gt;! Sind Sie sich sicher, dass Sie Ihre Brieftasche verschlüsseln möchten?</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="109"/>
        <source>Please re-enter your new wallet passphrase.</source>
        <translation>Bitte geben Sie Ihr neues Brieftaschenpasswort erneut ein.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="110"/>
        <source>Error: the supplied passphrases didn&apos;t match.</source>
        <translation>Fehler: Die eingegebenen Passphrasen stimmen nicht überein.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="111"/>
        <source>Wallet encryption failed.</source>
        <translation>Verschlüsselung der Brieftasche fehlgeschlagen.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="112"/>
        <source>Wallet Encrypted.
Remember that encrypting your wallet cannot fully protect your bitcoins from being stolen by malware infecting your computer.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="116"/>
        <source>Wallet is unencrypted, please encrypt it first.</source>
        <translation>Brieftasche nicht verschlüsselt, bitte zuerst verschlüsseln.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="117"/>
        <source>Enter the new passphrase for the wallet.</source>
        <translation>Gib eine neue Passphrase für die Brieftasche eine.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="118"/>
        <source>Re-enter the new passphrase for the wallet.</source>
        <translation>Gib die neue Passphrase erneut ein.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="119"/>
        <source>Wallet Passphrase Changed.</source>
        <translation>Passphrase geändert.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="120"/>
        <source>New Receiving Address</source>
        <translation>Neue Empfangsadresse</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="121"/>
        <source>You should use a new address for each payment you receive.

Label</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="125"/>
        <source>&lt;b&gt;Status:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Status:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="126"/>
        <source>, has not been successfully broadcast yet</source>
        <translation>; wurde noch nicht erfolgreich gesendet</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="127"/>
        <source>, broadcast through %d node</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="128"/>
        <source>, broadcast through %d nodes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="129"/>
        <source>&lt;b&gt;Date:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Datum:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="130"/>
        <source>&lt;b&gt;Source:&lt;/b&gt; Generated&lt;br&gt;</source>
        <translation>&lt;b&gt;Quelle:&lt;/b&gt; Generiert&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="131"/>
        <source>&lt;b&gt;From:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Von:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="132"/>
        <source>unknown</source>
        <translation>unbekannt</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="133"/>
        <source>&lt;b&gt;To:&lt;/b&gt; </source>
        <translation>&lt;b&gt;An:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="134"/>
        <source> (yours, label: </source>
        <translation> (Ihre, Bezeichnung: </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="135"/>
        <source> (yours)</source>
        <translation> (Ihre)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="136"/>
        <source>&lt;b&gt;Credit:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Gutschrift:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="137"/>
        <source>(%s matures in %d more blocks)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="138"/>
        <source>(not accepted)</source>
        <translation>(nicht angenommen)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="139"/>
        <source>&lt;b&gt;Debit:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Belastung:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="140"/>
        <source>&lt;b&gt;Transaction fee:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Transaktionsgebühr:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="141"/>
        <source>&lt;b&gt;Net amount:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Nettobetrag:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="142"/>
        <source>Message:</source>
        <translation>Nachricht:</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="143"/>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="144"/>
        <source>Generated coins must wait 120 blocks before they can be spent.  When you generated this block, it was broadcast to the network to be added to the block chain.  If it fails to get into the chain, it will change to &quot;not accepted&quot; and not be spendable.  This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Generierte Bitcoins müssen 120 Blöcke lang warten, bevor sie ausgegeben werden können. Als Sie diesen Block generierten, wurde er an das Netzwerk gesendet, um ihn der Blockkette hinzuzufügen. Falls dies fehlschlägt wird der Status in &quot;nicht angenommen&quot; geändert und der Betrag wird nicht verfügbar werden. Das kann gelegentlich passieren, wenn ein anderer Knoten einen Block zur selben Zeit wie Sie generierte.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="150"/>
        <source>Cannot write autostart/bitcoin.desktop file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="151"/>
        <source>Main</source>
        <translation>Haupt</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="152"/>
        <source>&amp;Start Bitcoin on window system startup</source>
        <translation>&amp;Bitcoin beim Systemstart ausführen</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="153"/>
        <source>&amp;Minimize on close</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="154"/>
        <source>version %s</source>
        <translation>Version %s</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="155"/>
        <source>Error in amount  </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="156"/>
        <source>Send Coins</source>
        <translation>Bitcoins überweisen</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="157"/>
        <source>Amount exceeds your balance  </source>
        <translation>Betrag übersteigt Ihr Guthaben  </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="158"/>
        <source>Total exceeds your balance when the </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="159"/>
        <source> transaction fee is included  </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="160"/>
        <source>Payment sent  </source>
        <translation>Zahlung gesendet</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="161"/>
        <source>Sending...</source>
        <translation>Senden...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="162"/>
        <source>Invalid address  </source>
        <translation>ungültige Adresse</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="163"/>
        <source>Sending %s to %s</source>
        <translation>Sende %s an %s</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="164"/>
        <source>CANCELLED</source>
        <translation>ABGEBROCHEN</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="165"/>
        <source>Cancelled</source>
        <translation>Abgebrochen</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="166"/>
        <source>Transfer cancelled  </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="167"/>
        <source>Error: </source>
        <translation>Fehler: </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="168"/>
        <source>Insufficient funds</source>
        <translation>Unzureichender Kontostand</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="169"/>
        <source>Connecting...</source>
        <translation>Verbinde...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="170"/>
        <source>Unable to connect</source>
        <translation>Kann nicht verbinden</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="171"/>
        <source>Requesting public key...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="172"/>
        <source>Received public key...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="173"/>
        <source>Recipient is not accepting transactions sent by IP address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="174"/>
        <source>Transfer was not accepted</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="175"/>
        <source>Invalid response received</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="176"/>
        <source>Creating transaction...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="177"/>
        <source>This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="180"/>
        <source>Transaction creation failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="181"/>
        <source>Transaction aborted</source>
        <translation>Transaktion abgebrochen</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="182"/>
        <source>Lost connection, transaction cancelled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="183"/>
        <source>Sending payment...</source>
        <translation>Sende Zahlung...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="184"/>
        <source>The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Fehler: Die Transaktion wurde abgelehnt. Dies kann passieren, wenn einige Ihrer Bitcoins aus Ihrer Brieftasche bereits ausgegeben wurden (z.B. aus einer Sicherungskopie Ihrer wallet.dat).</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="188"/>
        <source>Waiting for confirmation...</source>
        <translation>Warte auf Bestätigung...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="189"/>
        <source>The payment was sent, but the recipient was unable to verify it.
The transaction is recorded and will credit to the recipient,
but the comment information will be blank.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="193"/>
        <source>Payment was sent, but an invalid response was received</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="194"/>
        <source>Payment completed</source>
        <translation>Die Zahlung wurde abgeschlossen</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="195"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="196"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="197"/>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="198"/>
        <source>Bitcoin Address</source>
        <translation>Bitcoin Adresse</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="199"/>
        <source>This is one of your own addresses for receiving payments and cannot be entered in the address book.  </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="202"/>
        <source>Edit Address</source>
        <translation>Adresse bearbeiten</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="203"/>
        <source>Edit Address Label</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="204"/>
        <source>Add Address</source>
        <translation>Adresse hinzufügen</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="205"/>
        <source>Bitcoin</source>
        <translation>Bitcoin</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="206"/>
        <source>Bitcoin - Generating</source>
        <translation>Bitcoin - Generiere</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="207"/>
        <source>Bitcoin - (not connected)</source>
        <translation>Bitcoin - (nicht verbunden)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="208"/>
        <source>&amp;Open Bitcoin</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="209"/>
        <source>&amp;Send Bitcoins</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="210"/>
        <source>O&amp;ptions...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="211"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="212"/>
        <source>Program has crashed and will terminate.  </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="213"/>
        <source>Warning: Please check that your computer&apos;s date and time are correct.  If your clock is wrong Bitcoin will not work properly.</source>
        <translation>Bitte prüfen Sie Ihre Datums- und Uhrzeiteinstellungen, ansonsten kann es sein das BitCoin nicht ordnungsgemäss funktioniert.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="216"/>
        <source>beta</source>
        <translation>Beta</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../bitcoin.cpp" line="145"/>
        <source>Bitcoin Qt</source>
        <translation>Bitcoin Qt</translation>
    </message>
</context>
</TS>
?package(piratepack):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="piratepack" command="/usr/bin/piratepack"
